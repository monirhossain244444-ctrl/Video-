import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {INK, BN, fontFamily} from './theme';

const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill>
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{display: 'block'}}>{children}</svg>
  </AbsoluteFill>
);

/* ---------- লিফট (দরজা + ইন্ডিকেটর) ---------- */
export const Lift: React.FC<{x: number; y: number; w?: number; h?: number; open?: number; lit?: number}> = ({x, y, w = 400, h = 540, open = 0, lit = 0}) => {
  const cw = (w - 12) / 7;
  const pw = (w / 2) * (1 - open);
  return (
    <g>
      <rect x={x - 10} y={y - 112} width={w + 20} height={92} rx={14} fill="#0b0b0f" stroke={INK} strokeWidth={6} />
      {BN.map((d, i) => (
        <g key={i}>
          <rect x={x + 6 + i * cw} y={y - 100} width={cw - 8} height={68} rx={8} fill={i < lit ? '#ffcf33' : '#2a2a33'} />
          <text x={x + 6 + i * cw + (cw - 8) / 2} y={y - 50} fontSize={44} fontWeight={700} textAnchor="middle" fontFamily={fontFamily} fill={i < lit ? '#111' : '#555'}>{d}</text>
        </g>
      ))}
      <rect x={x - 14} y={y - 14} width={w + 28} height={h + 14} fill="#6c7691" stroke={INK} strokeWidth={6} />
      <rect x={x} y={y} width={w} height={h} fill={open > 0.02 ? '#fff4c9' : '#8892a8'} />
      {open > 0.02 && <rect x={x} y={y + h - 50} width={w} height={50} fill="#d9c58a" />}
      <rect x={x} y={y} width={pw} height={h} fill="#aab4c8" stroke={INK} strokeWidth={5} />
      <rect x={x + w - pw} y={y} width={pw} height={h} fill="#aab4c8" stroke={INK} strokeWidth={5} />
    </g>
  );
};

/* ---------- রাতের আকাশ + পুরোনো ভবন ---------- */
export const NightSky: React.FC<{blink7?: boolean}> = ({blink7 = true}) => {
  const f = useCurrentFrame();
  return (
    <Svg>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0a1030" /><stop offset="1" stopColor="#2a2f63" />
        </linearGradient>
      </defs>
      <rect width={1920} height={1080} fill="url(#sky)" />
      {Array.from({length: 60}).map((_, i) => (
        <circle key={i} cx={(i * 937) % 1920} cy={(i * 353) % 560} r={1.5 + (i % 3)} fill="#fff" opacity={0.5 + 0.5 * Math.sin(f / 10 + i)} />
      ))}
      <circle cx={1600} cy={170} r={72} fill="#ffeeb0" />
      <circle cx={1632} cy={150} r={64} fill="#0f1538" />
      <rect x={640} y={230} width={640} height={850} fill="#2b2f4a" stroke={INK} strokeWidth={6} />
      <rect x={620} y={210} width={680} height={36} fill="#3a3f5e" stroke={INK} strokeWidth={6} />
      {Array.from({length: 7}).map((_, r) =>
        Array.from({length: 5}).map((__, c) => {
          const lit = (r * 5 + c) % 4 === 1;
          const top = r === 0 && c === 2;
          const on = top ? (blink7 ? Math.sin(f / 5) > -0.2 : true) : lit;
          return <rect key={`${r}-${c}`} x={690 + c * 112} y={280 + r * 100} width={70} height={68} rx={6} fill={on ? '#ffe28a' : '#171b33'} stroke={INK} strokeWidth={4} />;
        }),
      )}
      <rect x={880} y={900} width={160} height={180} fill="#4a3a2d" stroke={INK} strokeWidth={6} />
      <rect y={1010} width={1920} height={70} fill="#11142b" />
    </Svg>
  );
};

/* ---------- লবি ---------- */
export const Lobby: React.FC<{open?: number; lit?: number; dim?: number}> = ({open = 0, lit = 0, dim = 0}) => (
  <>
    <Svg>
      <defs>
        <linearGradient id="lobbyWall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2b3866" /><stop offset="1" stopColor="#1b2444" />
        </linearGradient>
      </defs>
      <rect width={1920} height={780} fill="url(#lobbyWall)" />
      <rect y={780} width={1920} height={300} fill="#3a3f55" />
      <rect y={766} width={1920} height={24} fill="#202744" />
      {Array.from({length: 10}).map((_, i) => <line key={i} x1={i * 220 - 40} y1={790} x2={i * 320 - 700} y2={1080} stroke="#2e3348" strokeWidth={4} />)}
      <rect x={180} y={150} width={260} height={330} rx={12} fill="#10163a" stroke={INK} strokeWidth={6} />
      <circle cx={310} cy={240} r={44} fill="#ffeeb0" /><circle cx={332} cy={228} r={38} fill="#10163a" />
      <line x1={310} y1={150} x2={310} y2={480} stroke={INK} strokeWidth={5} />
      <line x1={180} y1={315} x2={440} y2={315} stroke={INK} strokeWidth={5} />
      <Lift x={1330} y={230} w={400} h={540} open={open} lit={lit} />
      <ellipse cx={1530} cy={790} rx={260} ry={26} fill="rgba(0,0,0,0.2)" />
    </Svg>
    {dim > 0 && <AbsoluteFill style={{background: `rgba(5,8,25,${dim})`}} />}
  </>
);

/* ---------- করিডোর ---------- */
export const Corridor: React.FC<{door?: boolean; warm?: boolean}> = ({door = true, warm = false}) => {
  const f = useCurrentFrame();
  const flick = f % 97 < 4 ? 0.55 : 1;
  return (
    <Svg>
      <rect width={1920} height={800} fill={warm ? '#4a4560' : '#33405f'} />
      <rect y={800} width={1920} height={280} fill={warm ? '#2f2a3d' : '#232a42'} />
      <rect y={780} width={1920} height={26} fill="#1c2236" />
      {[160, 660, 1160, 1660].map((lx) => (
        <g key={lx} opacity={flick}>
          <polygon points={`${lx},84 ${lx + 260},84 ${lx + 360},780 ${lx - 100},780`} fill="rgba(255,243,176,0.07)" />
          <rect x={lx} y={64} width={260} height={22} rx={8} fill="#fff3b0" stroke={INK} strokeWidth={4} />
        </g>
      ))}
      {[240, 820].map((dx) => (
        <g key={dx}>
          <rect x={dx} y={250} width={200} height={530} fill="#59627f" stroke={INK} strokeWidth={6} />
          <circle cx={dx + 160} cy={520} r={10} fill="#d4af37" stroke={INK} strokeWidth={3} />
        </g>
      ))}
      {door && (
        <g>
          <rect x={1540} y={230} width={260} height={550} fill="#6b5a46" stroke={INK} strokeWidth={6} />
          <rect x={1580} y={270} width={180} height={70} rx={10} fill="#e8e2d0" stroke={INK} strokeWidth={4} />
          <text x={1670} y={322} fontSize={44} fontWeight={700} textAnchor="middle" fontFamily={fontFamily} fill={INK}>স্টোর</text>
          <circle cx={1760} cy={520} r={12} fill="#d4af37" stroke={INK} strokeWidth={3} />
        </g>
      )}
    </Svg>
  );
};

/* ---------- সিঁড়ি ---------- */
export const Stairs: React.FC = () => (
  <Svg>
    <defs>
      <linearGradient id="stairWall" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#262d52" /><stop offset="1" stopColor="#3a3560" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#stairWall)" />
    <rect x={1400} y={120} width={240} height={300} rx={10} fill="#10163a" stroke={INK} strokeWidth={6} />
    <circle cx={1520} cy={200} r={34} fill="#ffeeb0" />
    {Array.from({length: 16}).map((_, i) => {
      const x = 200 + i * 100, y = 920 - i * 38;
      return <rect key={i} x={x} y={y} width={100} height={1080 - y} fill={i % 2 ? '#4a5272' : '#434b6b'} stroke={INK} strokeWidth={4} />;
    })}
    <line x1={200} y1={800} x2={1800} y2={192} stroke="#c9ced9" strokeWidth={10} strokeLinecap="round" />
    <line x1={200} y1={800} x2={200} y2={920} stroke="#c9ced9" strokeWidth={10} />
  </Svg>
);

/* ---------- পাহারাদারের ঘর ---------- */
export const GuardRoom: React.FC = () => (
  <>
    <Svg>
      <rect width={1920} height={800} fill="#4b3f66" />
      <rect y={800} width={1920} height={280} fill="#33293f" />
      <rect y={786} width={1920} height={20} fill="#251d30" />
      <rect x={160} y={140} width={300} height={380} rx={12} fill="#10163a" stroke={INK} strokeWidth={6} />
      <circle cx={310} cy={240} r={46} fill="#ffeeb0" /><circle cx={334} cy={226} r={40} fill="#10163a" />
      <line x1={310} y1={140} x2={310} y2={520} stroke={INK} strokeWidth={5} />
      <line x1={160} y1={330} x2={460} y2={330} stroke={INK} strokeWidth={5} />
      <rect x={1470} y={560} width={300} height={22} fill="#7a4e36" stroke={INK} strokeWidth={5} />
      <rect x={1490} y={582} width={20} height={210} fill="#7a4e36" stroke={INK} strokeWidth={4} />
      <rect x={1730} y={582} width={20} height={210} fill="#7a4e36" stroke={INK} strokeWidth={4} />
      <polygon points="1560,560 1680,560 1700,470 1540,470" fill="#ffcf5a" stroke={INK} strokeWidth={5} />
      <polygon points="1540,470 1700,470 1900,1080 1340,1080" fill="rgba(255,225,140,0.10)" />
      <rect x={240} y={880} width={760} height={110} rx={30} fill="#7d6a9a" stroke={INK} strokeWidth={6} />
      <ellipse cx={400} cy={900} rx={90} ry={40} fill="#d9d2ef" stroke={INK} strokeWidth={5} />
    </Svg>
  </>
);

/* ---------- মোশন গ্রাফিক্স ব্যাকগ্রাউন্ড ---------- */
export const GradientBg: React.FC<{a?: string; b?: string}> = ({a = '#14224d', b = '#5a3a7a'}) => {
  const f = useCurrentFrame();
  return (
    <Svg>
      <defs>
        <linearGradient id="gbg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} />
        </linearGradient>
      </defs>
      <rect width={1920} height={1080} fill="url(#gbg)" />
      {Array.from({length: 14}).map((_, i) => (
        <circle key={i} cx={(i * 389) % 1920} cy={(((i * 211) % 1080) + f * (0.3 + (i % 4) * 0.15)) % 1080} r={6 + (i % 4) * 5} fill="#fff" opacity={0.08 + (i % 3) * 0.03} />
      ))}
    </Svg>
  );
};
