import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {INK, FPS, sec, clamp, fontFamily} from './theme';

const sw = {stroke: INK, strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

/* ---------- Pop-up / Float / Pulse wrapper ---------- */
export const Pop: React.FC<{
  at: number; x: number; y: number; children: React.ReactNode;
  float?: number; pulse?: boolean; out?: number; z?: number;
}> = ({at, x, y, children, float = 0, pulse = false, out, z = 5}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - sec(at), fps, config: {damping: 9, stiffness: 140}});
  const o = out !== undefined ? 1 - clamp((f / FPS - out) / 0.25) : 1;
  if (f < sec(at) || o <= 0) return null;
  const fl = float ? Math.sin(f / 14) * float : 0;
  const pl = pulse ? 1 + Math.sin(f / 6) * 0.07 : 1;
  return (
    <div style={{position: 'absolute', left: x, top: y + fl, zIndex: z, opacity: o,
      transform: `translate(-50%,-50%) scale(${Math.max(s, 0) * pl})`}}>
      {children}
    </div>
  );
};

/* ---------- Icons (100x100) ---------- */
type IP = {size?: number};
const Svg: React.FC<{size: number; children: React.ReactNode}> = ({size, children}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible'}}>{children}</svg>
);
export const ClockIcon: React.FC<IP & {hour?: number; minute?: number}> = ({size = 120, hour = 2, minute = 0}) => (
  <Svg size={size}>
    <circle cx={50} cy={50} r={44} fill="#fff" {...sw} strokeWidth={6} />
    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => (
      <line key={i} x1={50 + 36 * Math.sin((i * Math.PI) / 6)} y1={50 - 36 * Math.cos((i * Math.PI) / 6)}
        x2={50 + 40 * Math.sin((i * Math.PI) / 6)} y2={50 - 40 * Math.cos((i * Math.PI) / 6)} {...sw} strokeWidth={3} />
    ))}
    <line x1={50} y1={50} x2={50} y2={22} {...sw} strokeWidth={5} transform={`rotate(${minute * 6} 50 50)`} />
    <line x1={50} y1={50} x2={50} y2={30} {...sw} strokeWidth={7} transform={`rotate(${hour * 30 + minute / 2} 50 50)`} />
    <circle cx={50} cy={50} r={5} fill={INK} />
  </Svg>
);
export const QuestionIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <circle cx={50} cy={50} r={44} fill="#ffd23f" {...sw} strokeWidth={6} />
    <text x={50} y={72} fontSize={66} fontWeight={700} textAnchor="middle" fill={INK} fontFamily={fontFamily}>?</text>
  </Svg>
);
export const ExclaimIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <circle cx={50} cy={50} r={44} fill="#ff4d4d" {...sw} strokeWidth={6} />
    <text x={50} y={72} fontSize={66} fontWeight={700} textAnchor="middle" fill="#fff" fontFamily={fontFamily}>!</text>
  </Svg>
);
export const HeartIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M50 88 C8 58 12 20 34 20 C43 20 50 27 50 34 C50 27 57 20 66 20 C88 20 92 58 50 88Z" fill="#ef4565" {...sw} strokeWidth={6} />
    <path d="M26 36 Q28 28 36 28" fill="none" stroke="#fff" strokeWidth={5} strokeLinecap="round" />
  </Svg>
);
export const BulbIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <circle cx={50} cy={40} r={28} fill="#ffe066" {...sw} strokeWidth={6} />
    <rect x={38} y={66} width={24} height={20} rx={5} fill="#aaa" {...sw} />
    <path d="M42 50 L50 38 L58 50" fill="none" {...sw} />
    {[-60, -30, 0, 30, 60].map((a) => (
      <line key={a} x1={50 + 38 * Math.sin((a * Math.PI) / 180)} y1={40 - 38 * Math.cos((a * Math.PI) / 180)}
        x2={50 + 48 * Math.sin((a * Math.PI) / 180)} y2={40 - 48 * Math.cos((a * Math.PI) / 180)} stroke="#f4a100" strokeWidth={4} strokeLinecap="round" />
    ))}
  </Svg>
);
export const WarnIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M50 10 L92 85 L8 85 Z" fill="#ffd23f" {...sw} strokeWidth={6} />
    <text x={50} y={78} fontSize={56} fontWeight={700} textAnchor="middle" fill={INK} fontFamily={fontFamily}>!</text>
  </Svg>
);
export const BagIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M34 30 Q34 8 50 8 Q66 8 66 30" fill="none" {...sw} strokeWidth={6} />
    <rect x={20} y={26} width={60} height={64} rx={16} fill="#3fae6a" {...sw} strokeWidth={6} />
    <rect x={30} y={56} width={40} height={22} rx={6} fill="#2e8b57" {...sw} />
    <line x1={50} y1={56} x2={50} y2={64} {...sw} />
  </Svg>
);
export const RotiIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <circle cx={50} cy={50} r={40} fill="#ecbf72" {...sw} strokeWidth={6} />
    <circle cx={36} cy={40} r={5} fill="#c98f3d" /><circle cx={62} cy={36} r={4} fill="#c98f3d" />
    <circle cx={54} cy={62} r={6} fill="#c98f3d" /><circle cx={34} cy={64} r={4} fill="#c98f3d" />
  </Svg>
);
export const GhostIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M18 90 L18 44 Q18 8 50 8 Q82 8 82 44 L82 90 L70 78 L58 90 L46 78 L34 90 L26 80 Z" fill="#f4f4ff" {...sw} strokeWidth={6} />
    <circle cx={38} cy={44} r={7} fill={INK} /><circle cx={62} cy={44} r={7} fill={INK} />
    <ellipse cx={50} cy={64} rx={8} ry={10} fill={INK} />
  </Svg>
);
export const EarIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M40 90 Q30 70 40 60 Q22 50 28 30 Q36 8 56 12 Q80 18 74 44 Q70 56 60 62 Q56 72 56 80 Q54 94 40 90Z" fill="#f2c29b" {...sw} strokeWidth={5} />
    <path d="M44 34 Q56 28 58 42 Q58 50 52 54" fill="none" {...sw} />
  </Svg>
);
export const CheckIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <circle cx={50} cy={50} r={44} fill="#3fae6a" {...sw} strokeWidth={6} />
    <path d="M28 52 L45 68 L74 34" fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
export const MoonIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <path d="M62 10 A42 42 0 1 0 90 62 A34 34 0 1 1 62 10Z" fill="#ffe9a3" {...sw} strokeWidth={5} />
  </Svg>
);
export const TiffinIcon: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <rect x={20} y={64} width={60} height={22} rx={6} fill="#9aa5b1" {...sw} />
    <rect x={20} y={40} width={60} height={22} rx={6} fill="#b9c3cd" {...sw} />
    <rect x={20} y={16} width={60} height={22} rx={6} fill="#9aa5b1" {...sw} />
    <path d="M28 16 Q50 -6 72 16" fill="none" {...sw} strokeWidth={5} />
  </Svg>
);
export const LiftMini: React.FC<IP> = ({size = 120}) => (
  <Svg size={size}>
    <rect x={16} y={10} width={68} height={80} rx={8} fill="#aab4c8" {...sw} strokeWidth={6} />
    <line x1={50} y1={10} x2={50} y2={90} {...sw} />
    <path d="M50 30 L66 48 L56 48 L56 66 L44 66 L44 48 L34 48Z" fill="#ffcf33" {...sw} strokeWidth={3} />
  </Svg>
);
export const EarWaves: React.FC<{size?: number}> = ({size = 90}) => {
  const f = useCurrentFrame();
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible'}}>
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${34 + i * 16} ${50 - 12 - i * 10} Q${50 + i * 16} 50 ${34 + i * 16} ${50 + 12 + i * 10}`} fill="none"
          stroke="#ffd23f" strokeWidth={7} strokeLinecap="round" opacity={0.4 + 0.6 * Math.abs(Math.sin(f / 6 - i))} />
      ))}
    </svg>
  );
};
export const Zzz: React.FC = () => (
  <div style={{fontFamily, fontWeight: 700, fontSize: 80, color: '#cfe3ff', WebkitTextStroke: '3px #111'}}>Z</div>
);

/* ---------- Bubbles ---------- */
export const Bubble: React.FC<{
  x: number; y: number; w: number; text: string; tail: number; at: number; until: number; bg?: string;
}> = ({x, y, w, text, tail, at, until, bg = '#ffffff'}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = f / FPS;
  if (t < at || t > until) return null;
  const s = spring({frame: f - sec(at), fps, config: {damping: 11, stiffness: 160}});
  const o = 1 - clamp((t - (until - 0.15)) / 0.15);
  return (
    <div style={{position: 'absolute', left: x - w / 2, top: y, width: w, zIndex: 20, opacity: o,
      transform: `scale(${s})`, transformOrigin: `${w / 2 + tail}px 100%`}}>
      <div style={{background: bg, border: '7px solid #111', borderRadius: 44, padding: '22px 34px', textAlign: 'center',
        fontFamily, fontWeight: 700, fontSize: 60, lineHeight: 1.3, color: '#111'}}>{text}</div>
      <div style={{position: 'absolute', left: w / 2 + tail - 20, bottom: -22, width: 40, height: 40, background: bg,
        borderRight: '7px solid #111', borderBottom: '7px solid #111', transform: 'rotate(45deg)'}} />
    </div>
  );
};

export const ThoughtBubble: React.FC<{x: number; y: number; at: number; out?: number; children: React.ReactNode}> = ({x, y, at, out, children}) => (
  <Pop at={at} x={x} y={y} out={out} float={6} z={15}>
    <div style={{position: 'relative'}}>
      <div style={{width: 260, height: 200, borderRadius: 120, background: '#fff', border: '7px solid #111',
        display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{children}</div>
      <div style={{position: 'absolute', left: -40, bottom: -50, width: 44, height: 44, borderRadius: 30, background: '#fff', border: '6px solid #111'}} />
      <div style={{position: 'absolute', left: -74, bottom: -86, width: 26, height: 26, borderRadius: 20, background: '#fff', border: '5px solid #111'}} />
    </div>
  </Pop>
);

/* ---------- Badge ---------- */
export const Badge: React.FC<{text: string; bg?: string; color?: string; size?: number; icon?: React.ReactNode}> = ({text, bg = '#ffd23f', color = '#111', size = 64, icon}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: 16, background: bg, color, border: '6px solid #111', borderRadius: 60,
    padding: '10px 38px', fontFamily, fontWeight: 700, fontSize: size, whiteSpace: 'nowrap'}}>{icon}{text}</div>
);

/* ---------- Props held by characters ---------- */
export const Torch: React.FC<{rot?: number; beam?: boolean}> = ({rot = 0, beam = false}) => (
  <g transform={`rotate(${rot})`}>
    {beam && <polygon points="-16,-64 16,-64 150,-520 -150,-520" fill="rgba(255,236,150,0.26)" />}
    <rect x={-11} y={-44} width={22} height={64} rx={8} fill="#3a3a3a" {...sw} strokeWidth={5} />
    <rect x={-18} y={-66} width={36} height={24} rx={6} fill="#ffd54a" {...sw} strokeWidth={5} />
  </g>
);
export const Cup: React.FC<{rot?: number; steam?: boolean}> = ({rot = 0, steam = false}) => {
  const f = useCurrentFrame();
  return (
    <g transform={`rotate(${rot})`}>
      {steam && [0, 1, 2].map((i) => (
        <path key={i} d="M0 -36 q8 -12 0 -24 q-8 -12 0 -24" fill="none" stroke="#fff" strokeWidth={4} strokeLinecap="round"
          opacity={0.5 + 0.4 * Math.sin(f / 8 + i)} transform={`translate(${-12 + i * 12} ${-((f + i * 10) % 30) * 0.4})`} />
      ))}
      <path d="M-20 -30 H20 V10 Q20 28 0 28 Q-20 28 -20 10 Z" fill="#fff" {...sw} strokeWidth={5} />
      <rect x={-17} y={-27} width={34} height={8} fill="#a0522d" />
      <path d="M20 -18 Q40 -18 40 -2 Q40 12 20 10" fill="none" {...sw} strokeWidth={5} />
    </g>
  );
};
export const Broom: React.FC = () => (
  <g>
    <line x1={0} y1={-190} x2={0} y2={70} stroke="#8b5a2b" strokeWidth={12} strokeLinecap="round" />
    <path d="M-30 70 L30 70 L42 130 L-42 130 Z" fill="#e5c158" {...sw} strokeWidth={5} />
  </g>
);
export const Bucket: React.FC = () => (
  <g>
    <path d="M-34 -10 L34 -10 L26 50 L-26 50 Z" fill="#4aa3df" {...sw} strokeWidth={5} />
    <path d="M-34 -10 Q0 -56 34 -10" fill="none" {...sw} strokeWidth={5} />
  </g>
);
export const Roti: React.FC<{r?: number}> = ({r = 24}) => (
  <g>
    <circle r={r} fill="#ecbf72" {...sw} strokeWidth={5} />
    <circle cx={-7} cy={-6} r={3} fill="#c98f3d" /><circle cx={8} cy={5} r={4} fill="#c98f3d" />
  </g>
);
export const Chair: React.FC = () => (
  <g>
    <rect x={78} y={170} width={144} height={260} rx={20} fill="#5b3a29" {...sw} strokeWidth={6} />
    <rect x={64} y={398} width={172} height={30} rx={10} fill="#7a4e36" {...sw} strokeWidth={6} />
    <path d="M84 428 L72 500 M216 428 L228 500" stroke={INK} strokeWidth={10} strokeLinecap="round" />
  </g>
);
