import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {FPS, sec, fontFamily, clamp} from './theme';
import {BOUNDS, SUBS, sceneRange} from './timeline';
import {Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7} from './scenesA';
import {Scene8, Scene9, Scene10, Scene11, Scene12, Scene13, Scene14} from './scenesB';

const SCENES = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7, Scene8, Scene9, Scene10, Scene11, Scene12, Scene13, Scene14];

// সাউন্ড ইফেক্ট (ভলিউম কম, ভয়েসওভারের নিচে)
const SFX: {at: number; file: string; vol: number}[] = [
  {at: 0.5, file: 'pop', vol: 0.2},
  {at: 14.1, file: 'pop', vol: 0.2},
  {at: 20.9, file: 'bell', vol: 0.18},
  ...[0, 1, 2, 3, 4, 5, 6].map((i) => ({at: 22.2 + 0.45 * i, file: 'tick', vol: 0.2})),
  {at: 25.95, file: 'door', vol: 0.2},
  {at: 26.9, file: 'ding', vol: 0.16},
  ...[0, 1, 2, 3, 4].map((i) => ({at: 28.8 + 0.18 * i, file: 'drip', vol: 0.12})),
  ...[0, 1, 2, 3, 4, 5, 6].map((i) => ({at: 33.0 + (6 / 7) * i + 0.3, file: 'step', vol: 0.25})),
  {at: 45.8, file: 'tick', vol: 0.22},
  {at: 61.0, file: 'pop', vol: 0.2},
  {at: 66.0, file: 'pop', vol: 0.2},
  {at: 70.7, file: 'chime', vol: 0.16},
  {at: 79.4, file: 'chime', vol: 0.16},
];

const Fade: React.FC<{children: React.ReactNode}> = ({children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, 8], [0, 1], {extrapolateRight: 'clamp'})}}>{children}</AbsoluteFill>;
};

const Caption: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const s = SUBS.find((x) => t >= x.s - 0.05 && t <= x.e + 0.1);
  if (!s || !s.cap) return null;
  const o = clamp((t - (s.s - 0.05)) / 0.15) * clamp((s.e + 0.1 - t) / 0.15);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 54, display: 'flex', justifyContent: 'center', zIndex: 50, opacity: o}}>
      <div style={{maxWidth: 1560, textAlign: 'center', background: 'rgba(10,14,30,0.74)', color: '#fff', fontFamily, fontWeight: 600,
        fontSize: 54, lineHeight: 1.35, padding: '14px 40px', borderRadius: 30, transform: `translateY(${(1 - o) * 14}px)`}}>
        {s.t}
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily}}>
    {SCENES.map((S, i) => {
      const {from, dur} = sceneRange(i);
      const extra = i < SCENES.length - 1 ? 8 : 0; // পরের সিনের সাথে ক্রসফেড
      return (
        <Sequence key={i} from={from} durationInFrames={dur + extra}>
          <Fade><S /></Fade>
        </Sequence>
      );
    })}
    <Caption />
    <Audio src={staticFile('voice.mp3')} />
    {SFX.map((s, i) => (
      <Sequence key={i} from={sec(s.at)} durationInFrames={sec(2)}>
        <Audio src={staticFile(`sfx/${s.file}.wav`)} volume={s.vol} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
