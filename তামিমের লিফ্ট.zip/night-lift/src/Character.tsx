import React from 'react';
import {useCurrentFrame} from 'remotion';
import {INK, Pt} from './theme';

export type Expr = 'neutral' | 'surprised' | 'scared' | 'happy' | 'worried' | 'sad' | 'angry' | 'relieved' | 'sleep';
export type Kind = 'tamim' | 'shuvo' | 'aziz';

export interface CharProps {
  kind: Kind;
  x: number; // পায়ের মাঝখান (পর্দার x)
  y: number; // পায়ের লেভেল (পর্দার y)
  scale?: number;
  flip?: boolean;
  rot?: number;
  expr?: Expr;
  talking?: boolean;
  pose?: 'stand' | 'sit' | 'crouch' | 'floor';
  walk?: boolean;
  look?: Pt;
  handL?: Pt;
  handR?: Pt;
  holdL?: React.ReactNode;
  holdR?: React.ReactNode;
  behind?: React.ReactNode;
  blanket?: boolean;
  seed?: number;
}

const SKIN = {tamim: '#F2C29B', shuvo: '#F3BE92', aziz: '#C48A5E'};
const BROW: Record<Expr, [number, number]> = {
  neutral: [80, 80], surprised: [64, 64], scared: [82, 66], worried: [82, 68],
  sad: [84, 70], angry: [70, 86], happy: [74, 74], relieved: [78, 78], sleep: [82, 82],
};

const Limb: React.FC<{d: string; w: number; color: string}> = ({d, w, color}) => (
  <g fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} stroke={INK} strokeWidth={w + 10} />
    <path d={d} stroke={color} strokeWidth={w} />
  </g>
);

const armPath = (sx: number, sy: number, h: Pt) => {
  const side = sx < 150 ? -1 : 1;
  const cx = (sx + h.x) / 2 + side * 28;
  const cy = (sy + h.y) / 2 + 12;
  return `M${sx} ${sy} Q${cx} ${cy} ${h.x} ${h.y}`;
};

export const Character: React.FC<CharProps> = (p) => {
  const f = useCurrentFrame();
  const {kind, x, y, scale = 1, flip = false, rot = 0, expr = 'neutral', talking = false, pose = 'stand',
    walk = false, look = {x: 0, y: 0}, holdL, holdR, behind, seed = 0} = p;
  const blanket = p.blanket ?? kind === 'shuvo';
  const skin = SKIN[kind];
  const shirt = kind === 'tamim' ? '#1b2f6b' : kind === 'aziz' ? '#a9d6a0' : '#f5c518';
  const pants = kind === 'tamim' ? '#262626' : kind === 'aziz' ? '#5d5648' : '#9aa0a6';
  const shoe = kind === 'aziz' ? '#555' : '#222';
  const shift = pose === 'sit' ? 60 : pose === 'crouch' ? 80 : pose === 'floor' ? 100 : 0;

  const bob = Math.sin(f / 16 + seed) * 3 - (walk ? Math.abs(Math.sin(f / 4)) * 9 : 0);
  const sway = Math.sin(f / 40 + seed) * 1.2;
  const bp = (f + seed * 37) % 120;
  const blink = expr === 'sleep' ? 0 : bp < 5 ? 0.1 + (0.9 * Math.abs(bp - 2.5)) / 2.5 : 1;
  const lvl = talking ? [0, 2, 1, 2, 1, 0, 2, 1][Math.abs(Math.floor(f / 3 + seed)) % 8] : 0;

  const defL: Pt = kind === 'shuvo' && blanket ? {x: 112, y: 262} : {x: 72, y: 340};
  const defR: Pt = kind === 'shuvo' && blanket ? {x: 188, y: 262} : {x: 228, y: 340};
  const hl = p.handL ?? defL;
  const hr = p.handR ?? defR;

  /* ---- legs ---- */
  const swing = walk ? Math.sin(f / 4) * 22 : 0;
  const leg = (cx: number, sgn: number) => (
    <g transform={`rotate(${swing * sgn} ${cx} 335)`}>
      {kind === 'shuvo' ? (
        <>
          <Limb d={`M${cx} 335 L${cx} 478`} w={24} color={skin} />
          <Limb d={`M${cx} 335 L${cx} 395`} w={38} color={pants} />
        </>
      ) : (
        <Limb d={`M${cx} 335 L${cx} 476`} w={38} color={pants} />
      )}
      <ellipse cx={cx} cy={488} rx={30} ry={14} fill={shoe} stroke={INK} strokeWidth={5} />
    </g>
  );
  let legs: React.ReactNode;
  if (pose === 'sit') {
    const sl = (cx: number) => (
      <g>
        {kind === 'shuvo' ? <Limb d={`M${cx} 405 L${cx} 478`} w={24} color={skin} /> : <Limb d={`M${cx} 405 L${cx} 476`} w={38} color={pants} />}
        <ellipse cx={cx} cy={488} rx={30} ry={14} fill={shoe} stroke={INK} strokeWidth={5} />
      </g>
    );
    legs = <>{sl(124)}{sl(176)}</>;
  } else if (pose === 'crouch') {
    legs = (
      <>
        <Limb d="M122 430 L82 470 L108 494" w={36} color={pants} />
        <Limb d="M178 430 L218 470 L192 494" w={36} color={pants} />
        <ellipse cx={110} cy={498} rx={28} ry={13} fill={shoe} stroke={INK} strokeWidth={5} />
        <ellipse cx={190} cy={498} rx={28} ry={13} fill={shoe} stroke={INK} strokeWidth={5} />
      </>
    );
  } else if (pose === 'floor') {
    legs = (
      <>
        <Limb d="M118 468 L100 492" w={24} color={skin} />
        <Limb d="M182 468 L200 492" w={24} color={skin} />
        <ellipse cx={98} cy={498} rx={26} ry={12} fill={shoe} stroke={INK} strokeWidth={5} />
        <ellipse cx={202} cy={498} rx={26} ry={12} fill={shoe} stroke={INK} strokeWidth={5} />
      </>
    );
  } else {
    legs = <>{leg(128, 1)}{leg(172, -1)}</>;
  }

  /* ---- face ---- */
  const big = expr === 'surprised' || expr === 'scared' ? 1.22 : 1;
  const er = (kind === 'shuvo' ? 17 : 13) * big;
  const ey = (kind === 'shuvo' ? 22 : 16) * big;
  const pr = (kind === 'shuvo' ? 8.5 : 6.5) * (expr === 'scared' ? 0.72 : 1);
  const [bo, bi] = kind === 'aziz' && expr === 'neutral' ? [86, 80] : BROW[expr];
  const dark = '#6b1d2a';
  const my = kind === 'aziz' ? 6 : 0;

  const eye = (cx: number) =>
    expr === 'sleep' ? (
      <path key={cx} d={`M${cx - 14} 108 Q${cx} 120 ${cx + 14} 108`} fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />
    ) : (
      <g key={cx} transform={`translate(${cx} 106) scale(1 ${blink})`}>
        <ellipse rx={er} ry={ey} fill="#fff" stroke={INK} strokeWidth={4} />
        <circle cx={look.x * 6} cy={look.y * 6} r={pr} fill={INK} />
        <circle cx={look.x * 6 + 2.5} cy={look.y * 6 - 2.5} r={2.2} fill="#fff" />
      </g>
    );

  let mouth: React.ReactNode;
  if (lvl === 1) mouth = <ellipse cx={150} cy={152} rx={14} ry={8} fill={dark} stroke={INK} strokeWidth={4} />;
  else if (lvl === 2)
    mouth = (
      <>
        <ellipse cx={150} cy={154} rx={17} ry={16} fill={dark} stroke={INK} strokeWidth={4} />
        <ellipse cx={150} cy={162} rx={9} ry={5} fill="#e0707f" />
      </>
    );
  else {
    switch (expr) {
      case 'surprised': mouth = <ellipse cx={150} cy={156} rx={12} ry={17} fill={dark} stroke={INK} strokeWidth={4} />; break;
      case 'scared': mouth = <ellipse cx={150} cy={154} rx={21} ry={11} fill={dark} stroke={INK} strokeWidth={4} />; break;
      case 'happy': mouth = <path d="M122 140 Q150 184 178 140 Z" fill={dark} stroke={INK} strokeWidth={4} strokeLinejoin="round" />; break;
      case 'relieved': mouth = <path d="M128 146 Q150 168 172 146" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />; break;
      case 'worried': case 'sad': mouth = <path d="M130 160 Q150 142 170 160" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />; break;
      case 'angry': mouth = <path d="M130 156 Q150 146 170 156" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />; break;
      case 'sleep': mouth = <path d="M136 150 Q150 158 164 150" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />; break;
      default: mouth = <path d="M132 150 Q150 156 168 150" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
    }
  }

  const drop = (f % 40) / 40;

  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 300, height: 520,
      transform: `translate(${x - 150}px, ${y - 510}px) rotate(${rot}deg) scale(${flip ? -scale : scale}, ${scale})`,
      transformOrigin: '150px 510px'}}>
      <svg width={300} height={520} viewBox="0 0 300 520" style={{overflow: 'visible'}}>
        <g transform={`translate(0 ${bob}) rotate(${sway} 150 500)`}>
          {behind}
          {legs}
          <g transform={`translate(0 ${shift})`}>
            {/* hips + torso */}
            <rect x={94} y={318} width={112} height={50} rx={20} fill={pants} stroke={INK} strokeWidth={6} />
            <rect x={92} y={182} width={116} height={160} rx={36} fill={shirt} stroke={INK} strokeWidth={6} />
            {kind === 'tamim' && (
              <>
                <rect x={93} y={326} width={114} height={16} fill="#111" />
                <rect x={142} y={324} width={16} height={20} rx={3} fill="#d4af37" stroke={INK} strokeWidth={3} />
                <path d="M126 184 L150 214 L174 184 Z" fill="#2c4a9a" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <path d="M182 204 h24 v20 q0 11 -12 15 q-12 -4 -12 -15z" fill="#e0b83a" stroke={INK} strokeWidth={4} />
                <line x1={150} y1={214} x2={150} y2={326} stroke={INK} strokeWidth={3} />
              </>
            )}
            {kind === 'aziz' && (
              <>
                <path d="M126 184 L150 212 L174 184 Z" fill="#8fc287" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
                <line x1={150} y1={212} x2={150} y2={338} stroke={INK} strokeWidth={3} />
                <Limb d="M188 188 Q176 250 158 320" w={16} color="#9ca3a8" />
              </>
            )}
            {kind === 'shuvo' && !blanket && <path d="M126 184 Q150 204 174 184" fill="none" stroke={INK} strokeWidth={4} />}
            {kind === 'shuvo' && blanket && (
              <g>
                <path d="M82 190 Q150 158 218 190 Q248 300 238 400 Q150 424 62 400 Q52 300 82 190Z" fill="#8f959b" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
                <path d="M100 250 Q150 270 200 250 M96 320 Q150 342 204 320" fill="none" stroke="#6f757b" strokeWidth={5} strokeLinecap="round" />
              </g>
            )}

            {/* head */}
            <rect x={134} y={160} width={32} height={34} fill={skin} stroke={INK} strokeWidth={5} />
            <circle cx={82} cy={114} r={13} fill={skin} stroke={INK} strokeWidth={5} />
            <circle cx={218} cy={114} r={13} fill={skin} stroke={INK} strokeWidth={5} />
            <circle cx={150} cy={110} r={68} fill={skin} stroke={INK} strokeWidth={6} />
            {kind === 'tamim' && <path d="M96 128 Q150 214 204 128 Q206 168 150 182 Q94 168 96 128Z" fill="rgba(50,35,30,0.30)" />}
            {kind === 'tamim' && <path d="M84 106 Q78 40 150 38 Q222 40 216 106 Q206 70 150 70 Q94 70 84 106Z" fill="#1a1a1a" stroke={INK} strokeWidth={5} strokeLinejoin="round" />}
            {kind === 'aziz' && <path d="M84 104 Q82 46 150 44 Q218 46 216 104 Q206 74 150 74 Q94 74 84 104Z" fill="#2a2a2a" stroke={INK} strokeWidth={5} strokeLinejoin="round" />}
            {kind === 'shuvo' && <path d="M84 96 L76 54 L106 72 L118 34 L140 66 L158 28 L174 66 L198 38 L198 74 L224 60 L216 100 Q150 58 84 96Z" fill="#2a1c14" stroke={INK} strokeWidth={5} strokeLinejoin="round" />}

            {/* brows & eyes */}
            <path d={`M104 ${bo} L140 ${bi}`} stroke={INK} strokeWidth={7} strokeLinecap="round" />
            <path d={`M160 ${bi} L196 ${bo}`} stroke={INK} strokeWidth={7} strokeLinecap="round" />
            {eye(122)}{eye(178)}
            {kind === 'aziz' && (
              <>
                <path d="M108 128 Q122 136 136 128" fill="none" stroke="#7a4b2c" strokeWidth={4} strokeLinecap="round" />
                <path d="M164 128 Q178 136 192 128" fill="none" stroke="#7a4b2c" strokeWidth={4} strokeLinecap="round" />
              </>
            )}
            {(expr === 'happy' || expr === 'relieved') && (
              <>
                <ellipse cx={106} cy={136} rx={11} ry={7} fill="#ff9ea8" opacity={0.7} />
                <ellipse cx={194} cy={136} rx={11} ry={7} fill="#ff9ea8" opacity={0.7} />
              </>
            )}
            <path d="M150 112 Q146 130 154 132" fill="none" stroke="#b9805a" strokeWidth={3} strokeLinecap="round" />
            <g transform={`translate(0 ${my})`}>{mouth}</g>
            {kind === 'aziz' && (
              <path d="M116 140 Q134 126 150 138 Q166 126 184 140 Q166 154 150 144 Q134 154 116 140Z" fill="#1a1a1a" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
            )}
            {expr === 'scared' && <path d="M214 62 q-10 18 0 22 q10 -4 0 -22z" fill="#8fd3ff" stroke={INK} strokeWidth={3} transform={`translate(0 ${drop * 10})`} />}
            {expr === 'sad' && (
              <>
                <path d="M110 126 q-7 12 0 16 q7 -4 0 -16z" fill="#8fd3ff" stroke={INK} strokeWidth={3} transform={`translate(0 ${drop * 26})`} opacity={1 - drop * 0.6} />
                <path d="M190 126 q-7 12 0 16 q7 -4 0 -16z" fill="#8fd3ff" stroke={INK} strokeWidth={3} transform={`translate(0 ${((drop + 0.5) % 1) * 26})`} opacity={0.8} />
              </>
            )}

            {/* arms + hands */}
            {kind === 'shuvo' ? (
              <>
                <Limb d={armPath(100, 208, hl)} w={22} color={skin} />
                <Limb d={armPath(200, 208, hr)} w={22} color={skin} />
                <circle cx={100} cy={208} r={20} fill={shirt} stroke={INK} strokeWidth={5} />
                <circle cx={200} cy={208} r={20} fill={shirt} stroke={INK} strokeWidth={5} />
              </>
            ) : (
              <>
                <Limb d={armPath(100, 208, hl)} w={32} color={shirt} />
                <Limb d={armPath(200, 208, hr)} w={32} color={shirt} />
              </>
            )}
            <circle cx={hl.x} cy={hl.y} r={kind === 'shuvo' ? 15 : 19} fill={skin} stroke={INK} strokeWidth={5} />
            <circle cx={hr.x} cy={hr.y} r={kind === 'shuvo' ? 15 : 19} fill={skin} stroke={INK} strokeWidth={5} />
            {holdL && <g transform={`translate(${hl.x} ${hl.y})`}>{holdL}</g>}
            {holdR && <g transform={`translate(${hr.x} ${hr.y})`}>{holdR}</g>}
          </g>
        </g>
      </svg>
    </div>
  );
};
