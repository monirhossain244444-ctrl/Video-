import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {
  weights: ['400', '600', '700'],
  subsets: ['bengali', 'latin'],
});

export const FPS = 30;
export const INK = '#111111';
export const sec = (s: number) => Math.round(s * FPS);
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const seg = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const eo = (x: number) => 1 - Math.pow(1 - x, 3);
export const eio = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
export const BN = ['১', '২', '৩', '৪', '৫', '৬', '৭'];
export type Pt = {x: number; y: number};
