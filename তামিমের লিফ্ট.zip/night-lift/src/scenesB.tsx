import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS, lerp, seg, eo, eio, BN, INK, fontFamily, Pt} from './theme';
import {Character} from './Character';
import {Corridor, GuardRoom, GradientBg, Lift} from './Backgrounds';
import {Pop, Bubble, Badge, QuestionIcon, HeartIcon, TiffinIcon, CheckIcon, GhostIcon, ClockIcon, BulbIcon, Zzz, Torch, Broom, Bucket, Roti, Chair} from './ui';

const useT = () => useCurrentFrame() / FPS;
const mixPt = (a: Pt, b: Pt, q: number): Pt => ({x: lerp(a.x, b.x, q), y: lerp(a.y, b.y, q)});

/* ৮) করিডোরে কম্বল জড়ানো ছেলেটা — কার্টুন */
export const Scene8: React.FC = () => {
  const t = useT();
  const tx = lerp(-150, 640, eio(seg(t, 0.2, 4.2)));
  const walking = t > 0.2 && t < 4.2;
  return (
    <AbsoluteFill>
      <Corridor />
      <svg style={{position: 'absolute', left: 0, top: 0}} width={1920} height={1080}>
        <rect x={1250} y={690} width={70} height={130} rx={10} fill="#aab4c8" stroke={INK} strokeWidth={5} />
        <circle cx={1285} cy={730} r={14} fill="#ffcf33" stroke={INK} strokeWidth={3} />
        <circle cx={1285} cy={780} r={14} fill="#8892a8" stroke={INK} strokeWidth={3} />
      </svg>
      <Character kind="shuvo" x={1400} y={1000} scale={1.2} pose="floor" expr="scared" look={{x: -0.6, y: 0}}
        handL={{x: 50, y: 197}} seed={3} />
      <Character kind="tamim" x={tx} y={1000} scale={1.2} walk={walking} expr={walking ? 'worried' : 'surprised'}
        look={{x: 1, y: 0}} handR={{x: 250, y: 300}} holdR={<Torch rot={90} beam />} />
      <Pop at={4.3} x={660} y={290} float={8} pulse><QuestionIcon size={130} /></Pop>
    </AbsoluteFill>
  );
};

/* ৯) ক্লোজ-আপ: আঙুল লিফটের বোতামে — কার্টুন/ইনসার্ট */
export const Scene9: React.FC = () => {
  const t = useT();
  const q = eo(seg(t, 0.1, 0.8));
  const fx = lerp(520, 0, q);
  const press = t > 0.9;
  const ring = (t - 0.9) % 0.8;
  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute'}}>
        <rect width={1920} height={1080} fill="#39425f" />
        <rect x={760} y={170} width={400} height={740} rx={36} fill="#aab4c8" stroke={INK} strokeWidth={8} />
        <rect x={820} y={220} width={280} height={120} rx={16} fill="#0b0b0f" stroke={INK} strokeWidth={6} />
        <text x={960} y={316} fontSize={96} fontWeight={700} textAnchor="middle" fontFamily={fontFamily} fill="#ffcf33">৭</text>
        {press && [0, 1].map((i) => {
          const r = ((ring + i * 0.4) % 0.8) / 0.8;
          return <circle key={i} cx={960} cy={540} r={70 + r * 120} fill="none" stroke="#ffcf33" strokeWidth={8} opacity={1 - r} />;
        })}
        <circle cx={960} cy={540} r={74} fill={press ? '#ffcf33' : '#7d869b'} stroke={INK} strokeWidth={8} />
        <path d="M960 505 L990 560 L930 560Z" fill={INK} />
        <circle cx={960} cy={740} r={74} fill="#7d869b" stroke={INK} strokeWidth={8} />
        <path d="M960 775 L990 720 L930 720Z" fill={INK} />
        <g transform={`translate(${fx} ${press ? 6 : 0})`}>
          <path d="M1480 330 Q1900 330 1960 700 L1960 900 Q1500 900 1440 650Z" fill="#8f959b" stroke={INK} strokeWidth={8} />
          <ellipse cx={1330} cy={545} rx={170} ry={90} fill="#f3be92" stroke={INK} strokeWidth={8} />
          <rect x={990} y={512} width={290} height={64} rx={32} fill="#f3be92" stroke={INK} strokeWidth={8} />
        </g>
      </svg>
    </AbsoluteFill>
  );
};

/* ১০) সংলাপ — স্পিচ বাবল */
export const Scene10: React.FC = () => {
  const t = useT();
  const sh = (t > 0.1 && t < 1.18) || (t > 5.0 && t < 6.2) || (t > 6.5 && t < 9.1);
  const tm = t > 1.48 && t < 4.64;
  const shExpr = t < 1.4 ? 'scared' : t < 4.9 ? 'worried' : 'sad';
  const tmExpr = t < 1.4 ? 'scared' : t < 6.4 ? 'neutral' : 'worried';
  return (
    <AbsoluteFill>
      <Corridor />
      <Character kind="shuvo" x={1280} y={1000} scale={1.1} pose="floor" expr={shExpr} talking={sh} look={{x: -0.7, y: 0}} seed={3} />
      <Character kind="tamim" x={520} y={1000} scale={1.1} expr={tmExpr} talking={tm} look={{x: 0.7, y: 0.2}} holdL={<Torch rot={170} />} handL={{x: 70, y: 330}} />
      <Bubble x={1250} y={330} w={640} tail={40} at={0.05} until={1.4} text="আপনি ভূত না তো?" />
      <Bubble x={600} y={170} w={940} tail={-50} at={1.4} until={4.85} bg="#e8f1ff" text="না রে, আমি পাহারাদার। তুই এত রাতে এখানে কেন?" />
      <Bubble x={1250} y={330} w={680} tail={40} at={4.85} until={6.4} text="বাবা নিচে কাজ করে।" />
      <Bubble x={1200} y={290} w={900} tail={80} at={6.4} until={9.4} text="একা লাগলে আমি লিফট ডাকি, যদি কেউ আসে।" />
    </AbsoluteFill>
  );
};

/* ১১) রুটি ভাগ করে খাওয়া — কার্টুন */
export const Scene11: React.FC = () => {
  const t = useT();
  const tamimHand = mixPt({x: 232, y: 300}, {x: 300, y: 320}, eo(seg(t, 0.6, 1.4)));
  const shHand =
    t < 1.9 ? mixPt({x: 112, y: 262}, {x: 40, y: 300}, eo(seg(t, 0.8, 1.4))) : mixPt({x: 40, y: 300}, {x: 128, y: 160}, eo(seg(t, 1.9, 2.5)));
  const hasRoti = t >= 1.4;
  return (
    <AbsoluteFill>
      <Corridor warm />
      <Character kind="shuvo" x={1090} y={1000} scale={1.1} pose="floor" expr={t < 2.0 ? 'worried' : 'happy'}
        talking={t > 2.7 && t < 5.0} look={{x: -0.5, y: 0.2}} seed={3} handL={shHand}
        holdL={hasRoti ? <Roti /> : undefined} />
      <Character kind="tamim" x={780} y={1000} scale={1.1} pose="crouch" expr={t < 1.4 ? 'neutral' : 'happy'}
        look={{x: 0.7, y: 0.2}} handR={tamimHand} holdR={!hasRoti ? <Roti /> : undefined}
        handL={{x: 70, y: 330}} />
      <Pop at={0.3} x={470} y={880} float={5}><TiffinIcon size={150} /></Pop>
      <Pop at={4.0} x={1090} y={330} float={8}><HeartIcon size={110} /></Pop>
      <Pop at={4.4} x={900} y={300} float={8}><HeartIcon size={80} /></Pop>
    </AbsoluteFill>
  );
};

/* ১২) আজিজকে ডেকে আনা, ছেলেকে কোলে তোলা — কার্টুন */
export const Scene12: React.FC = () => {
  const t = useT();
  const tamX = lerp(-150, 700, eo(seg(t, 0, 1.6)));
  const azWalk1 = lerp(-400, 330, eo(seg(t, 0.1, 1.7)));
  const azRun = lerp(330, 1180, eio(seg(t, 1.9, 2.9)));
  const azX = t < 1.8 ? azWalk1 : azRun;
  const azMoving = (t > 0.1 && t < 1.7) || (t > 1.9 && t < 2.9);
  const lifted = t >= 3.0;
  const shX = lerp(1400, 1215, eo(seg(t, 2.9, 3.4)));
  const shY = lerp(1000, 850, eo(seg(t, 3.0, 3.5)));
  const azExpr = t < 1.7 ? 'worried' : t < 3.0 ? 'surprised' : 'sad';
  return (
    <AbsoluteFill>
      <Corridor />
      {t >= 1.95 && (
        <svg style={{position: 'absolute', left: 0, top: 0}} width={1920} height={1080}>
          <g transform="translate(300 990) rotate(-8)"><rect x={0} y={-8} width={230} height={14} rx={6} fill="#8b5a2b" stroke={INK} strokeWidth={3} /><path d="M230 -26 L300 -34 L300 22 L230 14Z" fill="#e5c158" stroke={INK} strokeWidth={3} /></g>
          <g transform="translate(250 960)"><path d="M-34 -10 L34 -10 L26 40 L-26 40 Z" fill="#4aa3df" stroke={INK} strokeWidth={4} /></g>
        </svg>
      )}
      <Character kind="shuvo" x={lifted ? shX : 1400} y={lifted ? shY : 1000} scale={lifted ? 0.95 : 1.1} pose="floor"
        expr={t < 2.9 ? 'worried' : 'happy'} look={{x: -0.7, y: 0}} seed={3} />
      <Character kind="aziz" x={azX} y={1000} scale={1.15} walk={azMoving} expr={azExpr} seed={5}
        handL={lifted ? {x: 112, y: 300} : undefined} handR={lifted ? {x: 188, y: 300} : undefined}
        holdL={!lifted && t < 1.95 ? <Bucket /> : undefined} holdR={!lifted && t < 1.95 ? <Broom /> : undefined}
        look={{x: 0.6, y: 0}} />
      <Character kind="tamim" x={tamX} y={1000} scale={1.15} walk={t < 1.6} expr="neutral" talking={t > 0.3 && t < 1.5}
        look={{x: 0.4, y: 0}} handR={{x: 252, y: 250}} handL={{x: 70, y: 330}} />
      <Pop at={3.6} x={1215} y={430} float={8}><HeartIcon size={100} /></Pop>
      <Pop at={3.9} x={1330} y={470} float={8}><HeartIcon size={70} /></Pop>
    </AbsoluteFill>
  );
};

/* ১৩) পাহারাদারের ঘরে শুভ ঘুমাচ্ছে — কার্টুন */
export const Scene13: React.FC = () => {
  const t = useT();
  return (
    <AbsoluteFill>
      <GuardRoom />
      <svg style={{position: 'absolute', left: 0, top: 0}} width={1920} height={1080}>
        <Lift x={1010} y={320} w={150} h={220} open={0} lit={0} />
      </svg>
      <Character kind="shuvo" x={880} y={940} scale={1.0} rot={-90} expr="sleep" seed={3} />
      <Character kind="tamim" x={1270} y={1000} scale={1.2} pose="sit" behind={<Chair />}
        expr={t < 1.0 ? 'neutral' : 'relieved'} look={{x: -1, y: 0.4}} handL={{x: 126, y: 330}} holdL={<Torch rot={90} />} />
      {[0, 1, 2].map((i) => (
        <Pop key={i} at={0.6 + i * 0.5} x={420 + i * 60} y={780 - i * 60} float={8}><Zzz /></Pop>
      ))}
      <Pop at={4.2} x={1085} y={250} pulse><CheckIcon size={110} /></Pop>
    </AbsoluteFill>
  );
};

/* ১৪) শিক্ষা — মোশন গ্রাফিক্স তুলনা কার্ড */
const Card: React.FC<{left: number; top: number; bg: string; children: React.ReactNode; scale?: number}> = ({left, top, bg, children, scale = 1}) => (
  <div style={{position: 'absolute', left, top, width: 760, height: 520, background: bg, border: '8px solid #111', borderRadius: 48,
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, textAlign: 'center',
    fontFamily, fontWeight: 700, fontSize: 62, color: '#111', padding: 30, transform: `scale(${scale})`, transformOrigin: '50% 0%'}}>
    {children}
  </div>
);
export const Scene14: React.FC = () => {
  const t = useT();
  const l = lerp(-800, 130, eo(seg(t, 0.3, 1.1)));
  const r = lerp(2000, 1030, eo(seg(t, 0.9, 1.7)));
  const phaseB = eo(seg(t, 5.6, 6.2));
  const top = lerp(190, 70, phaseB);
  const sc = lerp(1, 0.72, phaseB);
  return (
    <AbsoluteFill>
      <GradientBg />
      <Card left={l - (760 * (1 - sc)) / 2} top={top} bg="#e9e6ff" scale={sc}>
        <GhostIcon size={200} />
        <div>যাকে ভূত ভেবে পালাই</div>
      </Card>
      <Card left={r - (760 * (1 - sc)) / 2} top={top} bg="#fff0c2" scale={sc}>
        <div style={{display: 'flex', gap: 20}}><ClockIcon size={170} hour={2} minute={0} /><HeartIcon size={170} /></div>
        <div>তার পেছনে কেউ একজন অপেক্ষা করে</div>
      </Card>
      <Pop at={2.0} x={960} y={450} pulse float={6}><BulbIcon size={130} /></Pop>
      <Pop at={5.8} x={960} y={880} pulse>
        <div style={{background: '#fff', border: '8px solid #111', borderRadius: 50, padding: '26px 60px', fontFamily, fontWeight: 700, fontSize: 74, color: '#111', textAlign: 'center', whiteSpace: 'nowrap'}}>
          শুধু চায় কেউ একটু এগিয়ে আসুক
        </div>
      </Pop>
      <Pop at={6.3} x={960} y={640} pulse><HeartIcon size={150} /></Pop>
    </AbsoluteFill>
  );
};
