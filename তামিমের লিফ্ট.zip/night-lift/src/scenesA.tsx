import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS, sec, lerp, seg, eo, eio, clamp, BN, INK, fontFamily} from './theme';
import {Character} from './Character';
import {NightSky, Lobby, Stairs} from './Backgrounds';
import {Pop, Badge, ThoughtBubble, ClockIcon, QuestionIcon, ExclaimIcon, MoonIcon, LiftMini, BagIcon, GhostIcon, EarWaves, Torch, Cup, Chair} from './ui';

const useT = () => useCurrentFrame() / FPS;

/* ১) প্রশ্ন + টাইটেল — মোশন গ্রাফিক্স */
export const Scene1: React.FC = () => {
  const t = useT();
  const p = eio(seg(t, 1.4, 4.6));
  return (
    <AbsoluteFill>
      <NightSky />
      <Pop at={0.2} x={960} y={100} float={4}>
        <Badge text="রাত দুটোর লিফট" size={74} icon={<MoonIcon size={72} />} />
      </Pop>
      <Pop at={0.6} x={330} y={560} float={8}><ClockIcon size={340} hour={2} minute={0} /></Pop>
      <svg style={{position: 'absolute', left: 1380, top: 200}} width={380} height={700} viewBox="0 0 380 700">
        <rect x={40} y={10} width={300} height={680} rx={16} fill="#171c3c" stroke={INK} strokeWidth={6} />
        {BN.map((d, i) => (
          <g key={i}>
            <line x1={40} x2={340} y1={10 + (7 - i) * 97 - 2} y2={10 + (7 - i) * 97 - 2} stroke="#3b4270" strokeWidth={3} />
            <text x={62} y={10 + (7 - i) * 97 - 30} fontSize={44} fontWeight={700} fontFamily={fontFamily} fill="#9aa5ff">{d}</text>
          </g>
        ))}
        <rect x={130} y={lerp(590, 20, p)} width={190} height={80} rx={10} fill="#aab4c8" stroke={INK} strokeWidth={6} />
        <line x1={225} y1={lerp(590, 20, p)} x2={225} y2={lerp(670, 100, p)} stroke={INK} strokeWidth={4} />
      </svg>
      <Pop at={3.8} x={960} y={540} pulse><QuestionIcon size={240} /></Pop>
    </AbsoluteFill>
  );
};

/* ২) পুরোনো ভবন + দুই পাহারাদার চলে গেছে — মোশন গ্রাফিক্স */
export const Scene2: React.FC = () => {
  const t = useT();
  const bx = (i: number) => lerp(780 + i * 230, 2300, eio(seg(t, 5.0 + i * 0.4, 7.6 + i * 0.4)));
  return (
    <AbsoluteFill>
      <NightSky />
      {[0, 1, 2].map((i) => (
        <React.Fragment key={i}>
          <Pop at={0.4 + i * 0.6} x={200 + i * 180} y={250} out={2.8} float={6}><MoonIcon size={110} /></Pop>
          <Pop at={0.7 + i * 0.6} x={200 + i * 180} y={430} out={2.8} float={6}><LiftMini size={110} /></Pop>
        </React.Fragment>
      ))}
      {[0, 1].map((i) => (
        <Pop key={i} at={3.0 + i * 0.5} x={bx(i)} y={810} z={8}>
          <div style={{textAlign: 'center'}}>
            <BagIcon size={190} />
            <Badge text={`পাহারাদার ${BN[i]}`} size={38} bg="#ffffff" />
          </div>
        </Pop>
      ))}
      <Pop at={3.4} x={1500} y={620} float={8} out={5.2}><ExclaimIcon size={110} /></Pop>
    </AbsoluteFill>
  );
};

/* ৩) তামিম চেয়ারে বসে — কার্টুন */
export const Scene3: React.FC = () => {
  const t = useT();
  return (
    <AbsoluteFill>
      <Lobby lit={0} />
      <Pop at={0.3} x={320} y={110} float={4}><Badge text="তৃতীয় রাত" size={54} icon={<MoonIcon size={56} />} /></Pop>
      <Character kind="tamim" x={760} y={1000} scale={1.4} pose="sit" behind={<Chair />}
        expr={t > 3.2 ? 'worried' : 'neutral'} look={{x: 0.6, y: 0}}
        handL={{x: 126, y: 330}} holdL={<Torch rot={90} />}
        handR={{x: 205, y: 262}} holdR={<Cup steam />} />
    </AbsoluteFill>
  );
};

/* ৪) দুটো বাজল, লিফটের সংখ্যা জ্বলছে — কার্টুন */
const BigClock: React.FC = () => {
  const t = useT();
  const p = eo(seg(t, 0.4, 1.2));
  const shake = t > 1.2 && t < 2.1 ? Math.sin(t * 60) * 8 : 0;
  return <div style={{transform: `rotate(${shake}deg)`}}><ClockIcon size={280} hour={1} minute={lerp(50, 60, p)} /></div>;
};
export const Scene4: React.FC = () => {
  const t = useT();
  const lit = t < 2.5 ? 0 : Math.min(7, Math.floor((t - 2.5) / 0.45) + 1);
  return (
    <AbsoluteFill>
      <Lobby lit={lit} />
      <Pop at={0.3} x={960} y={300} out={2.6}><BigClock /></Pop>
      <Character kind="tamim" x={760} y={1000} scale={1.4} pose="sit" behind={<Chair />}
        expr={t > 2.4 ? 'surprised' : 'neutral'} look={{x: 0.8, y: -0.3}}
        handL={{x: 126, y: 330}} holdL={<Torch rot={90} />}
        handR={{x: 205, y: 262}} holdR={<Cup steam />} />
      <Pop at={3.6} x={760} y={290} pulse><ExclaimIcon size={130} /></Pop>
    </AbsoluteFill>
  );
};

/* ৫) লিফটের দরজা খুলল, ভেতরে কেউ নেই — কার্টুন */
export const Scene5: React.FC = () => {
  const t = useT();
  const open = eo(seg(t, 0.3, 1.3));
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{transform: 'scale(1.12)', transformOrigin: '1530px 480px'}}>
        <Lobby open={open} lit={7} />
        <Character kind="tamim" x={640} y={1000} scale={1.3} expr="scared" look={{x: 1, y: 0}}
          handL={{x: 66, y: 330}} holdL={<Torch rot={-8} />} handR={{x: 236, y: 250}} />
      </AbsoluteFill>
      <Pop at={1.5} x={1180} y={330} float={8} pulse><QuestionIcon size={160} /></Pop>
    </AbsoluteFill>
  );
};

/* ৬) চা ছলকে পড়ল — কার্টুন */
export const Scene6: React.FC = () => {
  const t = useT();
  const tilt = -lerp(0, 80, eo(seg(t, 0.4, 1.0)));
  const stain = eo(seg(t, 1.0, 1.9));
  return (
    <AbsoluteFill>
      <Lobby open={1} lit={7} dim={0.15} />
      <Character kind="tamim" x={700} y={1000} scale={1.7} pose="sit" behind={<Chair />}
        expr={t > 3.4 ? 'angry' : 'scared'} look={{x: 1, y: 0}}
        handL={{x: 126, y: 330}} holdL={<Torch rot={90} />}
        handR={{x: 205, y: 262}} holdR={<Cup rot={tilt} />} />
      <svg style={{position: 'absolute', left: 0, top: 0, zIndex: 10}} width={1920} height={1080}>
        <ellipse cx={660} cy={836} rx={56 * stain} ry={26 * stain} fill="#7a3f1d" opacity={0.85} />
        {[0, 1, 2, 3, 4].map((i) => {
          const q = seg(t, 0.8 + i * 0.18, 1.2 + i * 0.18);
          if (q <= 0 || q >= 1) return null;
          return <ellipse key={i} cx={lerp(775, 662, q)} cy={lerp(700, 830, q * q)} rx={9} ry={12} fill="#a0522d" stroke={INK} strokeWidth={2} />;
        })}
      </svg>
      <ThoughtBubble x={1050} y={300} at={2.0}><GhostIcon size={130} /></ThoughtBubble>
    </AbsoluteFill>
  );
};

/* ৭) সিঁড়ি বেয়ে সাততলা — কার্টুন + প্রগ্রেস বার */
export const Scene7: React.FC = () => {
  const t = useT();
  const slot = 6 / 7;
  const k = Math.min(6, Math.floor(t / slot));
  const u = t - k * slot;
  const moveEnd = 0.42 * slot;
  const P = (i: number) => (i < 0 ? {x: 50, y: 996} : {x: 250 + 200 * i, y: 920 - 76 * i});
  const m = eio(seg(u, 0, moveEnd));
  const a = P(k - 1), b = P(k);
  const pos = {x: lerp(a.x, b.x, m), y: lerp(a.y, b.y, m)};
  const listening = m >= 1;
  const done = k + (listening ? 1 : 0);
  return (
    <AbsoluteFill>
      <Stairs />
      <div style={{position: 'absolute', left: 520, top: 84, width: 880, height: 14, background: '#2a3158', border: '4px solid #111', borderRadius: 10}} />
      <div style={{position: 'absolute', left: 520, top: 84, width: (880 * Math.max(0, done - 1)) / 6, height: 14, background: '#ffcf33', borderRadius: 10}} />
      {BN.map((d, i) => (
        <div key={i} style={{position: 'absolute', left: 520 + (i * 880) / 6 - 34, top: 55, width: 68, height: 68, borderRadius: 40,
          background: i < done ? '#ffcf33' : '#2a3158', border: '5px solid #111', color: i < done ? '#111' : '#8b93c9',
          fontFamily, fontWeight: 700, fontSize: 42, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{d}</div>
      ))}
      <Character kind="tamim" x={pos.x} y={pos.y} scale={0.75} walk={!listening} expr="worried"
        look={{x: 0.5, y: -0.4}} handR={listening ? {x: 208, y: 118} : undefined}
        holdL={<Torch rot={-12} beam />} />
      {listening && (
        <div style={{position: 'absolute', left: pos.x + 80, top: pos.y - 340}}><EarWaves size={110} /></div>
      )}
    </AbsoluteFill>
  );
};
